self.__BUILD_MANIFEST = {
  "/_error": [
    "static/chunks/c3ca526b45345e08.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error",
    "/api/contact",
    "/api/subscribe"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()