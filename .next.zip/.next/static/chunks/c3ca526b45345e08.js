__turbopack_load_page_chunks__("/_error", [
  "static/chunks/38e353c2b8e0c054.js",
  "static/chunks/36482b3351b033b6.js",
  "static/chunks/turbopack-85a793e04d253303.js"
])
