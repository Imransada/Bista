__turbopack_load_page_chunks__("/_app", [
  "static/chunks/399ce244c0ed1b56.js",
  "static/chunks/36482b3351b033b6.js",
  "static/chunks/turbopack-0d736c3db38010d5.js"
])
