var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/subscribe.js")
R.c("server/chunks/[root-of-the-server]__140e36b1._.js")
R.c("server/chunks/[root-of-the-server]__ec476382._.js")
R.m(86518)
module.exports=R.m(86518).exports
