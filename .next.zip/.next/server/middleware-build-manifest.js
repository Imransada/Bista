globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/399ce244c0ed1b56.js",
      "static/chunks/36482b3351b033b6.js",
      "static/chunks/turbopack-0d736c3db38010d5.js"
    ],
    "/_error": [
      "static/chunks/38e353c2b8e0c054.js",
      "static/chunks/36482b3351b033b6.js",
      "static/chunks/turbopack-85a793e04d253303.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b9a0fabf54a78ef2.js",
    "static/chunks/0afa5e999b6c353a.js",
    "static/chunks/980fed3ba22cdb6e.js",
    "static/chunks/turbopack-6ab7b03d2e5e4131.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];