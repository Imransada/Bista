module.exports=[60014,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_delete-myinfo_page_actions_81dd84ac.js.map