module.exports=[26758,a=>{a.v("/_next/static/media/favicon.e2a28598.ico")},38872,a=>{"use strict";let b={src:a.i(26758).default,width:670,height:372};a.s(["default",0,b])}];

//# sourceMappingURL=app_b9b1292a._.js.map