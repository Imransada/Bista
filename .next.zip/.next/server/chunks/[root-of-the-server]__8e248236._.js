module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},84423,(e,t,a)=>{t.exports=e.x("nodemailer-9c35dd349a8aaa9f",()=>require("nodemailer-9c35dd349a8aaa9f"))},16330,e=>{"use strict";var t=e.i(26747),a=e.i(90406),r=e.i(44898),s=e.i(62950),o=e.i(84423);async function i(e,t){if("POST"!==e.method)return t.status(405).json({message:"Method not allowed"});let{name:a,email:r,message:s}=e.body;if(console.log("Request Data:",{name:a,email:r,message:s}),!a||!r||!s)return t.status(400).json({message:"All fields are required"});try{console.log("Environment Variables:",{NEXT_PUBLIC_GMAIL:"bilalsadatravelandtours@gmail.com",NEXT_PUBLIC_GMAIL_PASSWORD:"nuwf hlfm wlen cnzp",EMAIL_USER:process.env.EMAIL_USER});let e=o.default.createTransport({service:"gmail",auth:{user:"bilalsadatravelandtours@gmail.com",pass:"nuwf hlfm wlen cnzp"}});console.log("Transporter created successfully"),await e.sendMail({from:process.env.EMAIL_USER,to:"bilalsadatravelandtours@gmail.com",subject:`New Contact Form Submission from ${a}`,html:`
        <div style="font-family: 'Outfit', sans-serif; max-width: 600px; margin: 0 auto; background: #fff; border: 1px solid #f3f4f6; border-radius: 8px; padding: 20px;">
          <h2 style="color: #f97316; font-size: 24px; border-bottom: 2px solid #dc2626; padding-bottom: 10px;">
            New Contact Form Submission
          </h2>
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong style="color: #555;">Name:</strong> ${a}</p>
            <p><strong style="color: #555;">Email:</strong> ${r}</p>
            <p><strong style="color: #555;">Message:</strong></p>
            <div style="background: #fff; padding: 15px; border-radius: 5px; border-left: 4px solid #f97316;">
              ${s.replace(/\n/g,"<br>")}
            </div>
          </div>
          <p style="color: #666; font-size: 12px;">
            This message was sent from your website contact form.
          </p>
        </div>
      `}),console.log("Email sent successfully to admin"),await e.sendMail({from:process.env.EMAIL_USER,to:r,subject:"Thank you for contacting Bilal Sada Travel and Tours!",html:`
        <div style="font-family: 'Outfit', sans-serif; max-width: 600px; margin: 0 auto; background: #fff; border: 1px solid #f3f4f6; border-radius: 8px; padding: 20px;">
          <h2 style="color: #f97316; font-size: 24px; border-bottom: 2px solid #dc2626; padding-bottom: 10px;">
            Thank you for reaching out, ${a}! 👋
          </h2>
          <p style="font-size: 16px; line-height: 1.6; color: #374151;">
            We have successfully received your message, and our team will get back to you as soon as possible, usually within 24 hours.
          </p>
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #333; margin-top: 0;">Your message:</h3>
            <div style="background: #fff; padding: 15px; border-radius: 5px; border-left: 4px solid #f97316;">
              <em>${s.replace(/\n/g,"<br>")}</em>
            </div>
          </div>
          <p style="color: #374151;">
            Best regards,<br>
            <strong style="color: #f97316;">Bilal Sada Travel and Tours</strong>
          </p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
          <p style="color: #999; font-size: 12px;">
            If you didn't send this message, please ignore this email.
          </p>
        </div>
      `}),console.log("Auto-reply sent successfully to user"),t.status(200).json({message:"Message sent successfully! We'll get back to you soon."})}catch(e){console.error("Email sending error:",e),t.status(500).json({message:"Failed to send message. Please try again or contact us directly."})}}e.s(["default",()=>i],74463);var n=e.i(74463),l=e.i(7031),d=e.i(81927),p=e.i(46432);let u=(0,s.hoist)(n,"default"),c=(0,s.hoist)(n,"config"),f=new r.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/contact",pathname:"/api/contact",bundlePath:"",filename:""},userland:n,distDir:".next",relativeProjectDir:""});async function g(e,a,r){f.isDev&&(0,p.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let s="/api/contact";s=s.replace(/\/index$/,"")||"/";let o=await f.prepare(e,a,{srcPage:s});if(!o){a.statusCode=400,a.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve());return}let{query:i,params:n,prerenderManifest:u,routerServerContext:c}=o;try{let t=e.method||"GET",r=(0,l.getTracer)(),o=r.getActiveScopeSpan(),p=f.instrumentationOnRequestError.bind(f),g=async o=>f.render(e,a,{query:{...i,...n},params:n,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:f.isDev,page:"/api/contact",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>p(e,...t)}).finally(()=>{if(!o)return;o.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let e=r.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;o.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),o.updateName(e)}else o.updateName(`${t} ${s}`)});o?await g(o):await r.withPropagatedContext(e.headers,()=>r.trace(d.BaseServerSpan.handleRequest,{spanName:`${t} ${s}`,kind:l.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},g))}catch(e){if(f.isDev)throw e;(0,t.sendError)(a,500,"Internal Server Error")}finally{null==r.waitUntil||r.waitUntil.call(r,Promise.resolve())}}e.s(["config",0,c,"default",0,u,"handler",()=>g],16330)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__8e248236._.js.map